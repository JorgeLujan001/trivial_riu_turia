### Use case: description, code  

[jsfiddle](https://jsfiddle.net/tsayen/ojb1b31r/2/)

### Expected behavior

### Actual behavior (stack traces, console logs etc)

### Library version

### Browsers

- [ ] Chrome 49+  
- [ ] Firefox 45+  

